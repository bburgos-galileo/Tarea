function enviarMensaje(mensaje){
    alert(mensaje);
    console.log(mensaje);
  }
  
  
  /**Tarea de Puntos extra #1 */
  function teclado(){
  
    var valor = prompt("Ingrese un valor");

    enviarMensaje('Valor ingresado: ' + valor); 
  
  }
  
  teclado()