function enviarMensaje(mensaje) {
  alert(mensaje);
  console.log(mensaje);
}

/**Variables y estructuras de control */
function condiciones() {
  var mes = 10;

  if (mes == 12 || mes == 1 || mes == 2) {
    enviarMensaje("es invierno");
  } else if (mes >= 3 && mes <= 5) {
    enviarMensaje("es primavera");
  } else if (mes >= 6 && mes <= 8) {
    enviarMensaje("es verano");
  } else if (mes >= 9 && mes <= 11) {
    enviarMensaje("es otoño");
  }

  enviarMensaje(
    "Carné: 9713763 Nombre Completo: Byron Othoniel Burgos Paniagua"
  );
}

condiciones();
